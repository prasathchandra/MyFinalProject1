package com.sample;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;


import org.junit.Assert;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sample.entity.Product;
import com.sample.repositary.ProductRepository;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

class ProductTestCase {
	@Autowired
	ProductRepository productRepository;
	//checking Product price
		@Test
		@Order(1)
		public void testSingleProduct()
		{
		Product product=this.productRepository.findById(1).get();
		Assert.assertEquals(300,product.getPrice(),0.0f);
		}

	
	//updating product price
	@Test
	@Order(2)
	public void testUpdate()
	{
	Product product=this.productRepository.findById(1).get();
	product.setPrice(300.00);
	this.productRepository.save(product);
	assertNotEquals(500.00,this.productRepository.findById(1).get().getPrice());
	}
	
	
	//deleting product
	@Test
	@Order(3)
	public void testDeleteProduct()
	{
	productRepository.deleteById(68);
	assertFalse(productRepository.existsById(68));
	}
}
