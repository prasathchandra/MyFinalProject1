package com.sample;

import static org.junit.Assert.assertFalse;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sample.entity.Customer;
import com.sample.repositary.CustomerRepository;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

class CustomerTestCase {

	
	@Autowired
	CustomerRepository customerRepository;

	//adding customer
	@Test
	@Order(1)
	public void testCreate()
	{

	Customer customer=new Customer();
	customer.setfName("riyas");
	customer.setlName("r");
	customer.setPhoneNo("9876663210");
	customer.setAddress("chennai");
	customer.setUserName("riyas@gmail.com");
	customer.setPassword("Ri123");
	customerRepository.save(customer);
	assertNotNull(customerRepository.findById(2).get());
	}
	
	//deleting customer
	@Test
	@Order(2)
	public void testDelete()
	{
	customerRepository.deleteById(1);
	assertFalse(customerRepository.existsById(1));
	}
}
